## Circuit Diagram


![image](https://user-images.githubusercontent.com/101162762/168478318-0e44f2a6-bd94-498b-8ebd-371551f715ac.png)





## Test Output :



![image](https://user-images.githubusercontent.com/101162762/168478486-393460f2-0734-4f36-b214-8da55d732a09.png)


![image](https://user-images.githubusercontent.com/101162762/168478512-262b3ac4-cbcf-415b-a028-4e712036a3aa.png)


