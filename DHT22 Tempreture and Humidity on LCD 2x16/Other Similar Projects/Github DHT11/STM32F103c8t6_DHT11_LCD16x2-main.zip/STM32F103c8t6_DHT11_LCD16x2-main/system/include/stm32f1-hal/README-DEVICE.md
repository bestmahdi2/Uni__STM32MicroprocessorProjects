# stm32cube_fw_f1_v183.zip

## STM32F1 HAL V1.1.7 / 20-October-2020

The `stm32f1xx_*.h` files were copied from the folder:

- `STM32Cube_FW_F1_V1.8.3/Drivers/STM32F1xx_HAL_Driver/Inc`
