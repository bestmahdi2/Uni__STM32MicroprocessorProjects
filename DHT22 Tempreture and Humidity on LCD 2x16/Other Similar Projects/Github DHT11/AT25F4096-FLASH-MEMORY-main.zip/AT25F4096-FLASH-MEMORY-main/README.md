# AT25F4096-FLASH-MEMORY
This is a STM32F103C8 MCU based example code for operating the AT25F4096 Flash Memory. For beginners and amateurs this Flash Memory is perfect to use and learn how a Flash Memory works. This Model of Flash is also available in Proteus so it will be easier to debug and find errors. 
The comments are also provided for better understanding. The library functions of the AT25F4096 covers all the basic functions of the Flash Memory.




-----------------Ignore these---------------------------
*STM32 external flash programming
*SPI flash memory running code example
*proteus flash memory simulation
github stm32 flash
