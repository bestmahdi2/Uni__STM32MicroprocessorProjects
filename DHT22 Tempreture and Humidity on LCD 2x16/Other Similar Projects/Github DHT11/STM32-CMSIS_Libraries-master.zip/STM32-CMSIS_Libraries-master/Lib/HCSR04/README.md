#### Usage (PWM variant)
```c
#include "HCSR04.h"

HCSR04_InitPWM();

uint32_t dist = HCSR04_ReadPWM();
```