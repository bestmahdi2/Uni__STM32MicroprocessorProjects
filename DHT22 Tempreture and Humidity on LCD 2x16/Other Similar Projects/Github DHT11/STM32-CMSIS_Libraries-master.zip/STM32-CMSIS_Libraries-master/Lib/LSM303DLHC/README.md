#### Accelerometer and Magnetometer Status
![Alt text](lsm303dlhc_status.png?raw=true "lsm303dlhc_status")
#### Accelerometer Init
![Alt text](lsm303dlhc_accel_init.png?raw=true "lsm303dlhc_accel_init")
#### Accelerometer Data
![Alt text](lsm303dlhc_accel_data.png?raw=true "lsm303dlhc_accel_data")
#### Magnetometer Init
![Alt text](lsm303dlhc_mag_init.png?raw=true "lsm303dlhc_mag_init")
#### Magnetometer Data
![Alt text](lsm303dlhc_mag_data.png?raw=true "lsm303dlhc_mag_data")
