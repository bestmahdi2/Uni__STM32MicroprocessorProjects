## DHT11

Simple example.

#### Usage
```c
#define DHT11_PORT GPIOB
#define DHT11_PIN  1

DHT11_TypeDef dht11;

DHT11_read(&dht11);
```

*All libraries are under development and are provided as is.*
