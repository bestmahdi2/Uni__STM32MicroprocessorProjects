/*
 * exti.h
 *
 *  Created on: 31 ���. 2019 �.
 *      Author: Admin
 */

#ifndef EXTI_H_
#define EXTI_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "stm32f1xx.h"

void EXTI_Init();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* EXTI_H_ */
