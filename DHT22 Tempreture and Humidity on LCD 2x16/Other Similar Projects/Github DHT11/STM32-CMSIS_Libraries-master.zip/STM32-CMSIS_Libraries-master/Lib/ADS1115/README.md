#### ADS1115 A0 Read
![Alt text](ads1115_a0_read.png?raw=true "ads1115_a0_read")
#### ADS1115 A0 Data
![Alt text](ads1115_a0_data.png?raw=true "ads1115_a0_data")
#### ADS1115 Terminal
![Alt text](ads1115_terminal.png?raw=true "ads1115_terminal")
