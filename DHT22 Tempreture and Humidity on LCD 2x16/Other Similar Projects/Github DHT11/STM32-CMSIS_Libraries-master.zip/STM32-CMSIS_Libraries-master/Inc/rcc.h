/*
 * rcc.h
 *
 * Created on: 13.11.2018
 *     Author: Admin
 */

#ifndef RCC_H_
#define RCC_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "stm32f1xx.h"

void RCC_Init();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* RCC_H_ */
