#ifndef _timer2_h_
#define _timer2_h_

#include "stm32f10x.h" 

void timer2_Init(void);
void delay_ms(uint32_t t);
void delay_us(uint32_t t);

#endif
